from django.apps import AppConfig


class DaoApiConfig(AppConfig):
    name = 'DAO_API'
