__author__ = 'jakir_shaikh'

from django.urls import path
from . import views

urlpatterns = [
    path('users/',views.user_list_create, name='user_list'),
    path('users/<int:id>/',views.user_get_put,name="user"),
    path('ideas/',views.ideas_list_create, name='idea_list'),
    path('ideas/<int:id>/',views.idea_get_put,name="user"),
    path('tags/',views.tags_list,name="tags"),
    path('review_status/',views.review_status_list, name="review_status"),
    path('roles/',views.roles_list, name="roles"),
    path('mail/',views.send_mail,name="send_mail"),
    path('ideabox/',views.ideabox_list_create, name='idea_list'),
    path('ideabox/<str:boxname>/',views.ideabox_get_put, name='ideabox_curd'),
    path('ideaneeds/',views.ideaneed_list_create, name='idea_needs_list'),
    path('ideaneeds/<int:id>',views.ideaneed_get_put, name='idea_needs'),
    path('ideaneeds/<str:box>/',views.ideaneed_get_by_box, name='idea_needs_by_box'),
    path('auth/',views.authenticate,name='authenticate_user')


]