__author__ = 'jakir_shaikh'
# using SendGrid's Python Library
# https://github.com/sendgrid/sendgrid-python
import sendgrid
import os
from .models import Ideas
from rest_framework.response import Response
from sendgrid.helpers.mail import *
from rest_framework import status
from .serializer import IdeaSerializer

def SendIdeaSubmissionNotification(idea_id,innovation_manager_email):
    try:
        idea = Ideas.objects.get(pk=idea_id)
    except Ideas.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    serializer = IdeaSerializer(idea)
    sg = sendgrid.SendGridAPIClient(apikey='SG.iZ4fYEOORNqc31IQRaoOuA.19EEDpqPltZP-Vl9qAROfOhNEAuZbPlsEV_pxtWSPjo')
    from_email = Email("noreply@cims.com")
    to_email = Email("jakir_shaikh@persistent.co.in")
    #to_email = Email(innovation_manager_email)
    subject = "New Project Idea Submission"
    content = Content("text/html",generateMailBody(serializer.data))
    mail = Mail(from_email, subject, to_email, content)
    response = sg.client.mail.send.post(request_body=mail.get())
    print(response.status_code)
    print(response.body)
    print(response.headers)
    return serializer

def generateMailBody(data):
    mailContent = "<html><p>New Idea Submission By :" \
                  ""+data['idea_owner']+"</p>" \
                   "<br><p>Idea : "+data['idea_title']+"</p>" \
                    "<p>Idea_description :"+data['idea_description' ]+"<br><p> Submission_date : "+data['submission_date']+"<p> " \
                     "<p>Category : "+data['category']+"</html>"
    return mailContent

