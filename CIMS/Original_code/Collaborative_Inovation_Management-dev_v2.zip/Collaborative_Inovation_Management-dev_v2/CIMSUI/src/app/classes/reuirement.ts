export class Reuirement {

    id:number;
    requirement:string;
    description:string;
    idea_box:string;

    constructor(id,requirement,description,idea_box){
        this.id=id;
        this.requirement=requirement;
        this.description=description;
        this.idea_box=idea_box;
    }

}


