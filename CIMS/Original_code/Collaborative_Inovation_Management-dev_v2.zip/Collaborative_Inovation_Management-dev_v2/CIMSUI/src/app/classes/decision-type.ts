export class DecisionType {

    value:string;

    constructor(value){
        this.value=value;
    }
}
