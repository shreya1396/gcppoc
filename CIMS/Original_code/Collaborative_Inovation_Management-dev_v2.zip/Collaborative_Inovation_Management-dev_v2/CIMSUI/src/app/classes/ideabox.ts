export class Ideabox {

    type:string;

    constructor(type){
        this.type=type;
    }
}
