export class Reviewerstatus {

    status:string;

    constructor(statsu){
        this.status=status;
    }
}
