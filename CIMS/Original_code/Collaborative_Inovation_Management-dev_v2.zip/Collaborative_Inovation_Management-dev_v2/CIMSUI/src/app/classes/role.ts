export class Role {
    role:string;

    constructor(role){
        this.role=role;
    }
}
