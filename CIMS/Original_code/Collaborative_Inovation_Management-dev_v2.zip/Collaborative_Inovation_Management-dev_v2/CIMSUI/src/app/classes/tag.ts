
export class Tag {
    tag_id:number;
    tag:string;

    constructor(id,name){
        this.tag_id=id;
        this.tag=name;
    }
}
