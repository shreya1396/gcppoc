import { FilterCatPipe } from './filter-cat.pipe';

describe('FilterCatPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterCatPipe();
    expect(pipe).toBeTruthy();
  });
});
