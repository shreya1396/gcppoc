import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cims-cards-reviewer',
  templateUrl: './cims-cards-reviewer.component.html',
  styleUrls: ['./cims-cards-reviewer.component.css']
})
export class CimsCardsReviewerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
