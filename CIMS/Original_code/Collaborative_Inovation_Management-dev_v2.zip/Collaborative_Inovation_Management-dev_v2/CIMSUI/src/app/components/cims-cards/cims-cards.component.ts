import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cims-cards',
  templateUrl: './cims-cards.component.html',
  styleUrls: ['./cims-cards.component.css']
})
export class CimsCardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
