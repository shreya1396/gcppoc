import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cims-ideaboxpage-layout',
  templateUrl: './cims-ideaboxpage-layout.component.html',
  styleUrls: ['./cims-ideaboxpage-layout.component.css']
})
export class CimsIdeaboxpageLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
