import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cims-admin-dashboard',
  templateUrl: './cims-admin-dashboard.component.html',
  styleUrls: ['./cims-admin-dashboard.component.css']
})
export class CimsAdminDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
