import { Component, OnInit } from '@angular/core';
import {MatTooltipModule} from '@angular/material/tooltip';
import {FormControl} from '@angular/forms';

@Component({
  selector: 'app-cims-idea-box-page',
  templateUrl: './cims-idea-box-page.component.html',
  styleUrls: ['./cims-idea-box-page.component.css']
})
export class CimsIdeaBoxPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
