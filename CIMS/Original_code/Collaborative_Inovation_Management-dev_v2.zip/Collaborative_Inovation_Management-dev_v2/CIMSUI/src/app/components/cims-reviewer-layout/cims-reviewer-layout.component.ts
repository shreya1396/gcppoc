import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-cims-reviewer-layout',
  templateUrl: './cims-reviewer-layout.component.html',
  styleUrls: ['./cims-reviewer-layout.component.css']
})
export class CimsReviewerLayoutComponent implements OnInit {

  constructor(private spinner:NgxSpinnerService) { }

  ngOnInit() {

    
  }

}
