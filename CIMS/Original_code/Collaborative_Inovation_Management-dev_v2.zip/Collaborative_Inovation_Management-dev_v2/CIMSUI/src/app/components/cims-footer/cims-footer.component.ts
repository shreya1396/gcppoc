import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'cims-footer',
    templateUrl: './cims-footer.component.html',
    styleUrls: ['./cims-footer.component.css']
})
export class CIMSFooterComponent implements OnInit {

    constructor() { }

    ngOnInit() { 

    }

}